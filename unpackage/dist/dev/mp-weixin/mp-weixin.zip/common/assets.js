"use strict";
const _imports_0$1 = "/static/home.png";
const _imports_0 = "/static/eraser.png";
const _imports_1 = "/static/fold.png";
const _imports_2 = "/static/clear.png";
exports._imports_0 = _imports_0$1;
exports._imports_0$1 = _imports_0;
exports._imports_1 = _imports_1;
exports._imports_2 = _imports_2;
//# sourceMappingURL=../../.sourcemap/mp-weixin/common/assets.js.map
